﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Data.SqlClient;
using System.Data;
namespace Assignment3
{
    public class SimpleStringComparer : IComparer
    {
        int IComparer.Compare(object x, object y)
        {
            string cmpstr = (string)x;
            return cmpstr.CompareTo((string)y);
        }
    }

    public class MyArrayList : ArrayList
    {
        public static void Main()
        {


            MyArrayList list = new MyArrayList();
          
            string fname = "", id = "";
            string filename = @"C:\Users\GEEKS4LEARNING\Desktop\Assignment2.txt";
            //=================- Creates and initializes a new ArrayList. -================

            
           
            
                while (fname != "Zzz")
                {
                    Console.Write("Enter your name: ");
                    fname = Console.ReadLine();
                    Console.Write("Input id number: ");
                    id = Console.ReadLine();
                    passData(fname, id);
                }
            Console.WriteLine("==================================================================================");
            Console.WriteLine("press any key to continue to data retrieval...");
            Console.ReadKey();

           //code to retrieve data from database, stores it to the ArrayList

            try
            {
                using (SqlConnection con = new SqlConnection())
                {
                    //prepare conectio string
                    con.ConnectionString = @"Data Source = DESKTOP-DCEFN0U\SQLEXPRESS; Initial Catalog=Assignment3; Integrated Security=True";

                    try
                    {

                        //Prepare SQL command that we want to query
                        SqlCommand cmd = new SqlCommand();
                        cmd.CommandType = CommandType.Text;
                        // cmd.CommandText = "SELECT * FROM MYTABLE";
                        cmd.CommandText = "SELECT * FROM custList";
                        cmd.Connection = con;

                        // open database connection.
                        con.Open();

                        Console.WriteLine("Connection Open ! ");

                        //Execute the query 
                        SqlDataReader sdr = cmd.ExecuteReader();

                        ////Retrieve data from table and Display result
                        while (sdr.Read())
                        {
                            string names = (string)sdr["CUS_NAME"];
                            string Cusid = (string)sdr["CUS_ID"];
                            list.Add($"{Cusid} {names}");

                        }
                        //Close the connection
                        con.Close();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message, "Can not open connection !");

                    }
                }
                Console.WriteLine("==================================================================================");
                Console.WriteLine("press any key to continue to file creation");
                Console.ReadKey();

                //=============================- create and write to a file -===========================
                using (TextWriter writer = File.CreateText(filename))
                {
                    Console.WriteLine("file created!!");
                    foreach (string a in list)
                    {
                        writer.WriteLine(a);
                    }
                }
                

            }
            catch (Exception)
            {
                Console.WriteLine("the was an error....");
            }

            Console.WriteLine("==================================================================================");
            Console.WriteLine("press any key to continue to read from file...");
            Console.ReadKey();

            //========================================- read from file -=============================

            if (System.IO.File.Exists(filename))
            {
                using (System.IO.StreamReader sr = System.IO.File.OpenText(filename))
                {
                    String input;
                    while ((input = sr.ReadLine()) != null)
                    {
                        Console.WriteLine(input);
                    }
                    Console.WriteLine("==================================================================================");
                    Console.WriteLine("press any key to continue to search for a string....");
                    Console.ReadKey();
                }
            }
            else
            {
                Console.WriteLine("File not found");
            }

            //the method called in line 41 passed data/parameters(fname, id). fn = fname, k = id
            void passData(string fn, string k)
            {
                //your connection string 
                string connString = @"Data Source = DESKTOP-DCEFN0U\SQLEXPRESS;Initial Catalog=Assignment3;Integrated Security=True";

                //create instanace of database connection
                SqlConnection conn = new SqlConnection(connString);
                try
                {
                    Console.WriteLine("Openning Connection ...");

                    //open connection
                    conn.Open();

                    Console.WriteLine("Connection successful!");

                    StringBuilder strBuilder = new StringBuilder();
                    StringReader strReader = new StringReader("");

                    strBuilder.Append("INSERT INTO custList(CUS_ID,CUS_NAME) VALUES ");
                    strBuilder.Append($"(N'{k}',N'{fn}')");
                    

                    string sqlQuery = strBuilder.ToString();
                    using (SqlCommand command = new SqlCommand(sqlQuery, conn)) //pass SQL query created above and connection
                    {
                        command.ExecuteNonQuery(); //execute the Query
                        Console.WriteLine("Query Executed.");
                    }
               

                        conn.Close();
                }
                catch (Exception e)
                {
                    Console.WriteLine("Error: " + e.Message);
                }
            }

            // BinarySearch requires a sorted ArrayList.
            list.Sort();

            // Compare results of an iterative search with a binary search

            Console.Write("Enter a string to search: ");
            string str = Console.ReadLine();
            string searchStr = list.IterativeSearch(str);
            Console.WriteLine(searchStr);

            int index = list.BinarySearch(str, new SimpleStringComparer());
            Console.WriteLine("Binary search, item found at index:    {0}", index);
            Console.ReadKey();
        }

        public string IterativeSearch(object finditem)
        {
            string index = Convert.ToString(finditem);

            for (int i = 0; i < this.Count; i++)
            {
                if (finditem.Equals(this[i]))
                {
                    index = Convert.ToString(this[i]);
                    break;
                }
            }
            return index;
        }
        
    }
}
